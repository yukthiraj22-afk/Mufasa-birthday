MUFA​SA BIRTHDAY GRAND LINE — ENHANCED VERSION

Includes:
- Animated pirate/ocean opening
- Interactive Grand Line map
- 9 personal memory chapters with your uploaded photos
- Memory collection system
- Hearts + progress bar
- Captain's 3-question challenge
- Locked final treasure that opens after 5 hearts
- Long final birthday letter
- Bonus photo gallery with full-screen photo viewer
- Small click/achievement sounds using the browser audio API
- Mobile-friendly design

Files:
index.html
assets/photo-first-meet.jpg
assets/photo-hardrock.jpg
assets/photo-iloveyou.jpg
assets/photo-ccd.jpg
assets/photo-love.jpg
assets/photo-whiskey.jpg
assets/photo-mysore.jpg
assets/photo-rough.jpg
assets/photo-back.jpg

Publishing:
Upload index.html and the entire assets folder to GitHub Pages, Netlify, or another static website host.
